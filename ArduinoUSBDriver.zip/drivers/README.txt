
With this version of Arduino a new all-in-one driver (with
security signature for Windows 8) is supplied.

The old (deprecated) drivers are still available in the
Old_Arduino_Drivers.zip

